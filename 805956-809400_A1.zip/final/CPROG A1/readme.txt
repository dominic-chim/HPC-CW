readme.txt

Program run with:
0.1 0.1 50 initial data.csv

to compile:
gcc *.c -o temp_dist2D